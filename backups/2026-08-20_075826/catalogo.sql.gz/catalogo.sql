--
-- PostgreSQL database dump
--

\restrict uCOBtODAEKtteem9XPIC5NrdG3sYQoiJvk5qWINDceUZUeDKVOyo3eT3TPQYwU5

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg13+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX IF EXISTS public.ix_product_status;
DROP INDEX IF EXISTS public.ix_product_pet_safe;
DROP INDEX IF EXISTS public.ix_product_name;
DROP INDEX IF EXISTS public.ix_product_light;
DROP INDEX IF EXISTS public.flyway_schema_history_s_idx;
ALTER TABLE IF EXISTS ONLY public.product DROP CONSTRAINT IF EXISTS pk_product;
ALTER TABLE IF EXISTS ONLY public.flyway_schema_history DROP CONSTRAINT IF EXISTS flyway_schema_history_pk;
DROP TABLE IF EXISTS public.product;
DROP TABLE IF EXISTS public.flyway_schema_history;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: florescer
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO florescer;

--
-- Name: product; Type: TABLE; Schema: public; Owner: florescer
--

CREATE TABLE public.product (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(100) NOT NULL,
    description character varying(500) NOT NULL,
    price numeric(10,2) NOT NULL,
    quantity_stock integer NOT NULL,
    care_requirements character varying(500) NOT NULL,
    availability boolean NOT NULL,
    status character varying(20) NOT NULL,
    image_path character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone,
    height_cm integer,
    light character varying(20),
    watering character varying(30),
    pet_safe boolean,
    environment character varying(20),
    difficulty character varying(10),
    includes_pot boolean,
    CONSTRAINT ck_product_difficulty CHECK (((difficulty IS NULL) OR ((difficulty)::text = ANY ((ARRAY['FACIL'::character varying, 'MEDIO'::character varying, 'DIFICIL'::character varying])::text[])))),
    CONSTRAINT ck_product_environment CHECK (((environment IS NULL) OR ((environment)::text = ANY ((ARRAY['INTERNO'::character varying, 'EXTERNO'::character varying, 'AMBOS'::character varying])::text[])))),
    CONSTRAINT ck_product_height CHECK (((height_cm IS NULL) OR ((height_cm > 0) AND (height_cm <= 1000)))),
    CONSTRAINT ck_product_light CHECK (((light IS NULL) OR ((light)::text = ANY ((ARRAY['SOL_PLENO'::character varying, 'MEIA_SOMBRA'::character varying, 'SOMBRA'::character varying])::text[])))),
    CONSTRAINT ck_product_price CHECK ((price > (0)::numeric)),
    CONSTRAINT ck_product_status CHECK (((status)::text = ANY ((ARRAY['ATIVO'::character varying, 'INATIVO'::character varying, 'ESGOTADO'::character varying])::text[]))),
    CONSTRAINT ck_product_stock CHECK ((quantity_stock >= 0)),
    CONSTRAINT ck_product_watering CHECK (((watering IS NULL) OR ((watering)::text = ANY ((ARRAY['DIARIA'::character varying, 'DUAS_A_TRES_VEZES_SEMANA'::character varying, 'SEMANAL'::character varying, 'QUINZENAL'::character varying, 'MENSAL'::character varying])::text[]))))
);


ALTER TABLE public.product OWNER TO florescer;

--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: florescer
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	create product table	SQL	V1__create_product_table.sql	98090255	florescer	2026-08-19 12:37:40.066618	28	t
2	2	add plant details	SQL	V2__add_plant_details.sql	-251889544	florescer	2026-08-19 12:37:40.142071	13	t
\.


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: florescer
--

COPY public.product (id, name, type, description, price, quantity_stock, care_requirements, availability, status, image_path, created_at, updated_at, height_cm, light, watering, pet_safe, environment, difficulty, includes_pot) FROM stdin;
808f604a-2f8f-4a3f-8d75-9dc39e11c9ea	Zamioculca	Folhagem	Resistente e elegante, aguenta pouca luz	65.00	4	Regar a cada 15 dias	t	ATIVO	3c2f8370-3fd1-437f-afe7-6b88731eb7bb.png	2026-08-19 13:18:43.502939	2026-08-19 13:18:43.502939	55	SOMBRA	QUINZENAL	f	INTERNO	FACIL	t
5e29c68b-dde2-4938-a9bb-7c539c4c39e7	Samambaia	Pendente	Folhagem verde e frondosa, otima para varanda	49.90	3	Manter o substrato umido	t	ATIVO	f3be8deb-3dea-42a3-9441-34085a0eb958.png	2026-08-19 12:51:41.278154	2026-08-19 13:21:35.719905	40	MEIA_SOMBRA	SEMANAL	t	INTERNO	FACIL	t
c2277a0f-f4cc-4418-9964-a64dddedb671	Cacto Mandacaru	Cacto	Resistente, aguenta esquecimento e sol forte	25.00	5	Regar pouco	t	ATIVO	39ab343d-ceb5-4ffc-b213-e15a4a0c79a8.png	2026-08-19 12:51:41.722219	2026-08-19 13:21:55.565154	30	SOL_PLENO	MENSAL	t	EXTERNO	FACIL	t
4deb632d-c95b-497c-a3da-ec112197d2de	Comigo-ninguem-pode	Folhagem	Folhas grandes e vistosas	80.00	2	Evitar sol direto	t	ATIVO	87f982eb-b741-45b8-8322-f53d30d6a823.png	2026-08-19 12:51:41.784613	2026-08-19 13:21:55.796851	90	SOMBRA	SEMANAL	f	INTERNO	MEDIO	t
8452e204-f060-40df-aa95-c84d4fb36bb8	Jiboia	Pendente	Cresce rapido e perdoa esquecimento	35.00	4	Regar quando o substrato secar	t	ATIVO	16dea413-b189-43c5-8dae-e696e498bd49.png	2026-08-19 12:51:41.844369	2026-08-19 13:21:56.038194	60	SOMBRA	SEMANAL	f	AMBOS	FACIL	t
89dca3a2-17ac-4760-acba-5bc3fe98c131	Orquidea Phalaenopsis	Flor	Floracao longa, exige atencao	120.00	1	Regar com moderacao	t	ATIVO	6a914783-34dc-4c5f-8009-f11949ef01e6.png	2026-08-19 12:51:41.921807	2026-08-19 13:21:56.270647	50	MEIA_SOMBRA	QUINZENAL	t	INTERNO	DIFICIL	t
cfa44d1c-495a-4900-b67c-5b01e5ef8693	Espada de São Jorge	Folhagem	Resistente, purifica o ar e quase não dá trabalho	45.90	7	Regar a cada 15 dias, tolera esquecimento	t	ATIVO	68dc34d0-5185-4477-a17a-d580d41f0f42.png	2026-08-19 13:37:08.791328	2026-08-19 13:37:08.791328	70	MEIA_SOMBRA	SEMANAL	f	INTERNO	FACIL	t
\.


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: florescer
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: product pk_product; Type: CONSTRAINT; Schema: public; Owner: florescer
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT pk_product PRIMARY KEY (id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: florescer
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: ix_product_light; Type: INDEX; Schema: public; Owner: florescer
--

CREATE INDEX ix_product_light ON public.product USING btree (light);


--
-- Name: ix_product_name; Type: INDEX; Schema: public; Owner: florescer
--

CREATE INDEX ix_product_name ON public.product USING btree (name);


--
-- Name: ix_product_pet_safe; Type: INDEX; Schema: public; Owner: florescer
--

CREATE INDEX ix_product_pet_safe ON public.product USING btree (pet_safe);


--
-- Name: ix_product_status; Type: INDEX; Schema: public; Owner: florescer
--

CREATE INDEX ix_product_status ON public.product USING btree (status);


--
-- PostgreSQL database dump complete
--

\unrestrict uCOBtODAEKtteem9XPIC5NrdG3sYQoiJvk5qWINDceUZUeDKVOyo3eT3TPQYwU5

